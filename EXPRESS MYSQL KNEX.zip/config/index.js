const Path = require("path");
module.exports = {
  rootPath: Path.resolve(__dirname, ".."),
  jwtkey: "SECRET",
};
